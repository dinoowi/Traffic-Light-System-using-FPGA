module clock_divider #(
    parameter DIVIDER_VALUE = 24999999
)(
    input wire clk_in,
    input wire reset,
    output reg clk_out
);
    reg [25:0] counter;

    always @(posedge clk_in or negedge reset) begin
        if (!reset) begin
            counter <= 0;
            clk_out <= 0;
        end else begin
            if (counter == DIVIDER_VALUE) begin
                counter <= 0;
                clk_out <= ~clk_out;
            end else begin
                counter <= counter + 1;
            end
        end
    end
endmodule