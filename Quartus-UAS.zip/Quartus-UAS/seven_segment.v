module seven_segment (
    input wire clk_mux,
    input wire reset,
    input wire [3:0] display_digit,
    output reg [3:0] dig,
    output reg [7:0] seg
);
    reg [3:0] puluhan;
    reg [3:0] satuan;
    reg [3:0] biner_tampil;
    reg digit_select;

    // Pemisah Puluhan dan Satuan
    always @(*) begin
        if (display_digit == 10) begin
            puluhan = 4'd1;
            satuan  = 4'd0;
        end else begin
            puluhan = 4'd0;
            satuan  = display_digit;
        end
    end

    // Selector Flag Multiplexing
    always @(posedge clk_mux or negedge reset) begin
        if (!reset) digit_select <= 0;
        else        digit_select <= ~digit_select;
    end

    // Mux Pemilih Digit
    always @(*) begin
        case (digit_select)
            1'b0: begin
                dig = 4'b1110; // Aktifkan DIG1 (Kanan)
                biner_tampil = satuan;
            end
            1'b1: begin
                dig = 4'b1101; // Aktifkan DIG2 (Kiri)
                biner_tampil = puluhan;
            end
            default: begin
                dig = 4'b1111;
                biner_tampil = 4'd0;
            end
        endcase
    end

    // Decoder Biner ke Segmen (Common Anode) dengan Leading-Zero Blanking
    always @(*) begin
        if (biner_tampil == 4'd0 && digit_select == 1'b1 && display_digit < 10) begin
            seg = 8'hFF; // Matikan angka 0 di depan angka 9 s.d 1
        end else begin
            case (biner_tampil)
                4'd0:    seg = 8'hC0;
                4'd1:    seg = 8'hF9;
                4'd2:    seg = 8'hA4;
                4'd3:    seg = 8'hB0;
                4'd4:    seg = 8'h99;
                4'd5:    seg = 8'h92;
                4'd6:    seg = 8'h82;
                4'd7:    seg = 8'hF8;
                4'd8:    seg = 8'h80;
                4'd9:    seg = 8'h90;
                default: seg = 8'hBF;
            endcase
        end
    end
endmodule