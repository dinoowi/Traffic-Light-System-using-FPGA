module top_module (
    input wire clk,          // PIN_23
    input wire reset,        // PIN_88 (Terbaru dari Pin Planner lu)
    output wire [2:0] light, // PIN_120, 115, 113
    output wire [3:0] dig,   // PIN_137, 136, 135, 133
    output wire [7:0] seg    // PIN_128 s.d 127
);

    wire clk_1s;
    wire clk_mux;
    wire [3:0] shared_digit;

    // 1. Instansiasi Clock 1 Detik
    clock_divider #(.DIVIDER_VALUE(24999999)) u_clk_1s (
        .clk_in(clk),
        .reset(reset),
        .clk_out(clk_1s)
    );

    // 2. Instansiasi Clock Mux Cepat (~1kHz)
    clock_divider #(.DIVIDER_VALUE(24999)) u_clk_mux (
        .clk_in(clk),
        .reset(reset),
        .clk_out(clk_mux)
    );

    // 3. Instansiasi Otak Utama FSM
    traffic_fsm u_fsm (
        .clk_1s(clk_1s),
        .reset(reset),
        .light(light),
        .display_digit(shared_digit)
    );

    // 4. Instansiasi Driver 7-Segment Multiplexing
    seven_segment u_seven_seg (
        .clk_mux(clk_mux),
        .reset(reset),
        .display_digit(shared_digit),
        .dig(dig),
        .seg(seg)
    );

endmodule