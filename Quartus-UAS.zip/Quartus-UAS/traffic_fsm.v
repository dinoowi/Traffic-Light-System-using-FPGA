module traffic_fsm (
    input wire clk_1s,
    input wire reset,
    output reg [2:0] light,
    output reg [3:0] display_digit
);
    localparam S_MERAH  = 2'b01,
               S_KUNING = 2'b10,
               S_HIJAU  = 2'b11;

    reg [1:0] current_state = S_MERAH;
    reg [1:0] next_state    = S_MERAH;
    reg [3:0] timer = 0;

    // State Register
    always @(posedge clk_1s or negedge reset) begin
        if (!reset) begin
            current_state <= S_MERAH;
            timer <= 0;
        end else begin
            current_state <= next_state;
            if (current_state != next_state)
                timer <= 0;
            else
                timer <= timer + 1;
        end
    end

    // Next State Logic
    always @(*) begin
        case (current_state)
            S_MERAH:  next_state = (timer >= 9) ? S_KUNING : S_MERAH;  // 10 Detik
            S_KUNING: next_state = (timer >= 1) ? S_HIJAU  : S_KUNING; // 2 Detik
            S_HIJAU:  next_state = (timer >= 4) ? S_MERAH  : S_HIJAU;  // 5 Detik
            default:  next_state = S_MERAH;
        endcase
    end

    // Output Lampu LED
    always @(*) begin
        case (current_state)
            S_MERAH:  light = 3'b001;
            S_KUNING: light = 3'b010;
            S_HIJAU:  light = 3'b100;
            default:  light = 3'b001;
        endcase
    end

    // Logika Angka Hitung Mundur
    always @(*) begin
        case (current_state)
            S_MERAH:  display_digit = 10 - timer;
            S_KUNING: display_digit = 2 - timer;
            S_HIJAU:  display_digit = 5 - timer;
            default:  display_digit = 0;
        endcase
    end
endmodule